package executor.test

class Book {
	 String name
    static constraints = {
    }
}
